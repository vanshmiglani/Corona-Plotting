function updateMap() {
  fetch("/data.json")
    .then((response) => response.json())
    .then((rsp) => {
      console.log(rsp.countries);
      rsp.countries.forEach((element) => {
        longitude = element.longitude
        latitude = element.latitude

        //Marker on the map
        new mapboxgl.Marker({
          draggable: true,
        })
          .setLngLat([longitude, latitude])
          .addTo(map);

      });
    });
}
updateMap();
