const express = require('express')
const app = express()
const http = require('http')
const fs = require('fs')
const e = require('express')
const port = 3000
const index = fs.readFileSync('../index.html')
const about = fs.readFileSync('../about.html')

app.get('/index', (req,res)=>{
    res.end(index)
})
app.get('/about', (req,res)=>{
    res.end(about)
})

app.listen(port, ()=>{
    console.log('Server is running at local port')

})